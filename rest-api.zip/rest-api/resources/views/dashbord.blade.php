<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>PEMBELIAN</title>
</head>
<body>
<table class="table table-dark table-striped">
<thead>
    <tr>
      <th scope="col">NO</th>
      <th scope="col">ayam</th>
      <th scope="col">ayam goreng</th>
      <th scope="col">ayam panggang</th>
      <th scope="col">total bayar</th>
      <th scope="col">edit</th>
      <th scope="col">delete</th>
    </tr>
  </thead>
  <tbody>
    @foreach($pembelian as $data)
    <tr>
      <th scope="row">{{$data->id}}</th>
      <td>{{$data->ayam}}</td>
      <td>{{$data->ayam_goreng}}</td>
      <td>{{$data->ayam_panggang}}</td>
      <td>{{$data->total_harga}}</td>
      <td><a href="/edit/{{ $data->id }}"class="btn btn-warning">Edit</a></td>
      <td><a href="/dashbord/{{ $data->id }}"  class="btn btn-md btn-danger">Delete</a></td>
    </tr>
    @endforeach
  </tbody>
</table>
<a href="/add"class="btn btn-success" role="button">Tambah Pembelian</a>
</body>
</html>